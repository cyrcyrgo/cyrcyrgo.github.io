/* ============================================================
   KOBG AI - training.js - 训练管理模块
   管理训练会话、上下文、训练计时等
   ============================================================ */

const KOBGTraining = (() => {
    // ========== 高压力训练稳定性配置 ==========
    const MAX_COMPILE_RESULTS = 100;    // 最多保留 100 条编译结果
    const MAX_CONTEXT_MESSAGES = 50;    // 最多保留 50 条上下文消息
    const MAX_CONSECUTIVE_FAILURES = 3; // 连续失败 3 轮后自动中止
    const CODE_SIZE_WARN = 500000;      // 代码超过 500KB 时警告

    let trainingState = {
        isRunning: false,
        isPaused: false,
        startTime: null,
        elapsedTime: 0,
        totalDuration: 0, // 秒
        currentRound: 0,
        totalRounds: 0,
        generatedCode: null,
        compileResults: [],
        contextMessages: [], // 上下文消息
        timerInterval: null,
        onTickCallback: null,
        consecutiveFailures: 0,  // 连续失败计数
        waitResumeInterval: null // waitForResume 的 interval 引用
    };

    /**
     * 获取训练状态
     */
    function getState() {
        return { ...trainingState };
    }

    /**
     * 是否正在训练
     */
    function isRunning() {
        return trainingState.isRunning;
    }

    /**
     * 清除上下文
     */
    function clearContext() {
        stopTimer();
        cleanupWaitResume();
        trainingState.contextMessages = [];
        trainingState.generatedCode = null;
        trainingState.compileResults = [];
        trainingState.currentRound = 0;
        trainingState.consecutiveFailures = 0;
        console.log('[Training] 上下文已清除');
    }

    /**
     * 清理 waitForResume 的 interval
     */
    function cleanupWaitResume() {
        if (trainingState.waitResumeInterval) {
            clearInterval(trainingState.waitResumeInterval);
            trainingState.waitResumeInterval = null;
        }
    }

    /**
     * 完全重置训练状态
     */
    function reset() {
        stopTimer();
        cleanupWaitResume();
        trainingState = {
            isRunning: false,
            isPaused: false,
            startTime: null,
            elapsedTime: 0,
            totalDuration: 0,
            currentRound: 0,
            totalRounds: 0,
            generatedCode: null,
            compileResults: [],
            contextMessages: [],
            timerInterval: null,
            onTickCallback: null,
            consecutiveFailures: 0,
            waitResumeInterval: null
        };
        console.log('[Training] 训练状态已完全重置');
    }

    /**
     * 启动计时器
     */
    function startTimer(onTick) {
        stopTimer();
        if (onTick) trainingState.onTickCallback = onTick;
        trainingState.startTime = Date.now() - trainingState.elapsedTime * 1000;
        trainingState.timerInterval = setInterval(() => {
            trainingState.elapsedTime = Math.floor((Date.now() - trainingState.startTime) / 1000);
            if (trainingState.onTickCallback) trainingState.onTickCallback(trainingState.elapsedTime);
        }, 1000);
    }

    /**
     * 停止计时器
     */
    function stopTimer() {
        if (trainingState.timerInterval) {
            clearInterval(trainingState.timerInterval);
            trainingState.timerInterval = null;
        }
    }

    /**
     * 开始训练
     * @param {number} durationSeconds - 训练时长（秒）
     * @param {function} onProgress - 进度回调
     * @param {function} onComplete - 完成回调
     * @param {function} onError - 错误回调
     * @param {function} onTick - 计时回调
     * @param {function} onStreamChunk - 流式输出回调
     * @param {string} customInstruction - 自定义训练指令
     * @param {number} customRounds - 自定义训练轮数（可选）
     * @param {number} qaPerRound - 每轮问答数量（默认5）
     */
    async function startTraining(durationSeconds, onProgress, onComplete, onError, onTick, onStreamChunk, customInstruction, customRounds, qaPerRound) {
        if (trainingState.isRunning) {
            throw new Error('训练已在运行中');
        }

        trainingState.isRunning = true;
        trainingState.isPaused = false;
        trainingState.totalDuration = durationSeconds;
        trainingState.totalRounds = customRounds && customRounds >= 1 ? customRounds : Math.max(1, Math.ceil(durationSeconds / 30));
        trainingState.currentRound = 0;
        trainingState.elapsedTime = 0;
        trainingState.qaPerRound = qaPerRound || 5;

        startTimer(onTick);

        try {
            // 按时间模式：使用固定间隔；按轮数模式：等待每轮输出完成后立即开始下一轮
            const useFixedInterval = !(customRounds && customRounds >= 1);
            const roundInterval = useFixedInterval
                ? Math.min((durationSeconds * 1000) / trainingState.totalRounds, 30000)
                : 0;

            for (let i = 0; i < trainingState.totalRounds; i++) {
                if (!trainingState.isRunning) break;
                if (trainingState.isPaused) {
                    await waitForResume();
                }

                trainingState.currentRound = i + 1;
                const progress = trainingState.currentRound / trainingState.totalRounds;
                onProgress(progress, trainingState.currentRound, trainingState.totalRounds);

                // 执行训练轮次 - 等待完成，不抛异常
                let roundResult;
                if (onStreamChunk) {
                    roundResult = await executeTrainingRoundStream(onStreamChunk, customInstruction, trainingState.qaPerRound);
                } else {
                    roundResult = await executeTrainingRound(customInstruction, trainingState.qaPerRound);
                }

                // 检查连续失败（熔断）
                if (trainingState.consecutiveFailures >= MAX_CONSECUTIVE_FAILURES) {
                    const errMsg = `连续 ${trainingState.consecutiveFailures} 轮失败，训练自动中止`;
                    console.error('[Training]', errMsg);
                    onError(new Error(errMsg));
                    return;
                }

                // 按时间模式：固定间隔；按轮数模式：仅短暂延迟后继续
                if (i < trainingState.totalRounds - 1 && trainingState.isRunning) {
                    if (useFixedInterval) {
                        await sleep(roundInterval);
                    } else {
                        // 轮数模式：等待1秒缓冲后立即进入下一轮
                        await sleep(1000);
                    }
                }
            }

            if (trainingState.isRunning) {
                onComplete();
            }
        } catch (error) {
            onError(error);
        } finally {
            trainingState.isRunning = false;
            stopTimer();
        }
    }

    /**
     * 执行单轮训练（流式）- 带错误恢复和内存保护
     * @param {function} onStreamChunk - 流式回调 (chunkText)
     * @param {string} customInstruction - 自定义训练指令
     * @param {number} qaPerRound - 每轮问答数量
     * @returns {Promise<{success: boolean, error?: string}>}
     */
    async function executeTrainingRoundStream(onStreamChunk, customInstruction = '', qaPerRound = 5) {
        try {
            let code;
            if (trainingState.generatedCode) {
                code = await KOBGAPI.continueTrainingStream(
                    trainingState.generatedCode,
                    onStreamChunk,
                    customInstruction,
                    qaPerRound
                );
            } else {
                code = await KOBGAPI.generateCppCodeStream(onStreamChunk, customInstruction, qaPerRound);
            }

            if (code) {
                trainingState.generatedCode = code;
                trainingState.consecutiveFailures = 0; // 重置连续失败计数

                const compileResult = await KOBGCompiler.compile(code);
                pushCompileResult({
                    round: trainingState.currentRound,
                    timestamp: Date.now(),
                    success: compileResult.success,
                    output: compileResult.output,
                    errors: compileResult.errors
                });

                pushContextMessage({
                    role: 'assistant',
                    content: code
                });

                // 代码大小检查
                if (code.length > CODE_SIZE_WARN) {
                    console.warn(`[Training] 代码过大 (${(code.length / 1024).toFixed(1)}KB)，建议重置上下文`);
                }
            }

            return { success: true };
        } catch (error) {
            console.error('[Training] 第 ' + trainingState.currentRound + ' 轮失败:', error.message);
            trainingState.consecutiveFailures++;
            pushCompileResult({
                round: trainingState.currentRound,
                timestamp: Date.now(),
                success: false,
                output: '',
                errors: [error.message]
            });
            return { success: false, error: error.message };
        }
    }

    /**
     * 执行单轮训练（非流式）- 带错误恢复和内存保护
     * @param {string} customInstruction - 自定义训练指令
     * @param {number} qaPerRound - 每轮问答数量
     * @returns {Promise<{success: boolean, error?: string}>}
     */
    async function executeTrainingRound(customInstruction = '', qaPerRound = 5) {
        try {
            let code;
            if (trainingState.generatedCode) {
                code = await KOBGAPI.continueTraining(
                    trainingState.generatedCode,
                    customInstruction,
                    qaPerRound
                );
            } else {
                code = await KOBGAPI.generateCppCode(customInstruction, qaPerRound);
            }

            if (code) {
                trainingState.generatedCode = code;
                trainingState.consecutiveFailures = 0;

                const compileResult = await KOBGCompiler.compile(code);
                pushCompileResult({
                    round: trainingState.currentRound,
                    timestamp: Date.now(),
                    success: compileResult.success,
                    output: compileResult.output,
                    errors: compileResult.errors
                });

                pushContextMessage({
                    role: 'assistant',
                    content: code
                });

                if (code.length > CODE_SIZE_WARN) {
                    console.warn(`[Training] 代码过大 (${(code.length / 1024).toFixed(1)}KB)，建议重置上下文`);
                }
            }

            return { success: true };
        } catch (error) {
            console.error('[Training] 第 ' + trainingState.currentRound + ' 轮失败:', error.message);
            trainingState.consecutiveFailures++;
            pushCompileResult({
                round: trainingState.currentRound,
                timestamp: Date.now(),
                success: false,
                output: '',
                errors: [error.message]
            });
            return { success: false, error: error.message };
        }
    }

    /**
     * 安全压入编译结果（自动裁剪）
     */
    function pushCompileResult(result) {
        trainingState.compileResults.push(result);
        if (trainingState.compileResults.length > MAX_COMPILE_RESULTS) {
            trainingState.compileResults = trainingState.compileResults.slice(-MAX_COMPILE_RESULTS);
        }
    }

    /**
     * 安全压入上下文消息（自动裁剪）
     */
    function pushContextMessage(msg) {
        trainingState.contextMessages.push(msg);
        if (trainingState.contextMessages.length > MAX_CONTEXT_MESSAGES) {
            trainingState.contextMessages = trainingState.contextMessages.slice(-MAX_CONTEXT_MESSAGES);
        }
    }

    /**
     * 暂停训练
     */
    function pauseTraining() {
        if (!trainingState.isRunning) return;
        trainingState.isPaused = true;
        stopTimer();
        console.log('[Training] 已暂停');
    }

    /**
     * 恢复训练
     */
    function resumeTraining() {
        if (!trainingState.isPaused) return;
        trainingState.isPaused = false;
        startTimer();
        console.log('[Training] 已恢复');
    }

    /**
     * 停止训练
     */
    function stopTraining() {
        trainingState.isRunning = false;
        trainingState.isPaused = false;
        stopTimer();
        cleanupWaitResume();
        console.log('[Training] 已停止，连续失败计数:', trainingState.consecutiveFailures);
    }

    /**
     * 获取当前生成的代码
     */
    function getGeneratedCode() {
        return trainingState.generatedCode;
    }

    function setGeneratedCode(code) {
        trainingState.generatedCode = code;
    }

    /**
     * 获取编译结果
     */
    function getCompileResults() {
        return [...trainingState.compileResults];
    }

    /**
     * 获取训练日志
     */
    function getTrainingLog() {
        return trainingState.compileResults.map(r => ({
            type: r.success ? 'success' : 'error',
            round: r.round,
            time: new Date(r.timestamp).toLocaleTimeString(),
            message: r.success ? `第 ${r.round} 轮编译成功` : `第 ${r.round} 轮失败: ${r.errors?.join(', ') || '未知错误'}`,
            errors: r.errors || []
        }));
    }

    /**
     * 导出训练状态（用于保存）
     */
    function exportState() {
        const kbSize = KOBGKnowledgeTest ? KOBGKnowledgeTest.getKnowledgeBase().length : 0;
        return {
            generatedCode: trainingState.generatedCode,
            totalRounds: trainingState.totalRounds,
            currentRound: trainingState.currentRound,
            compileResults: trainingState.compileResults ? [...trainingState.compileResults] : [],
            knowledgeSize: kbSize
        };
    }

    /**
     * 导入训练状态（用于加载）
     */
    function importState(data) {
        if (!data) return false;
        trainingState.generatedCode = data.code || data.generatedCode || null;
        trainingState.totalRounds = data.totalRounds || 0;
        trainingState.currentRound = data.currentRound || 0;
        trainingState.compileResults = data.compileResults || [];
        trainingState.elapsedTime = 0;
        return true;
    }

    // 辅助函数
    function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    function waitForResume() {
        cleanupWaitResume();
        return new Promise(resolve => {
            trainingState.waitResumeInterval = setInterval(() => {
                if (!trainingState.isPaused || !trainingState.isRunning) {
                    cleanupWaitResume();
                    resolve();
                }
            }, 200);
        });
    }

    return {
        getState,
        isRunning,
        clearContext,
        reset,
        startTraining,
        executeTrainingRound,
        executeTrainingRoundStream,
        pauseTraining,
        resumeTraining,
        stopTraining,
        getGeneratedCode,
        setGeneratedCode,
        getCompileResults,
        getTrainingLog,
        exportState,
        importState
    };
})();