# 中国象棋 AI 对战平台

纯前端运行的中国象棋在线对战平台，人类玩家通过浏览器与基于 OpenAI API 的 LLM 进行对弈。无需后端服务器。

AI 角色定位为“碾压人类”的象棋大师，每一步都会附带嘲讽语句，在棋力和心理上双重打压。

## 特性

- 完整中国象棋规则引擎（走法验证、将军检测、将死/困毙判定、帅将照面等）
- 标准记谱法双向转换（内部坐标 ↔ “炮二平五”等）
- 直接从前端调用 OpenAI Chat Completions 接口
- AI 输出 JSON 解析 + 非法走法自动重试（最多 3 次）
- 本地贪心兜底引擎：接口不可用或 AI 走法全非时仍可对弈
- AI 嘲讽气泡（打字机效果），将军/吃子时高亮
- OpenAI API Key 与对局状态保存在 localStorage
- 支持选择执红 / 执黑、认输、重新开局
- 桌面端 / 移动端响应式布局

## 本地运行

直接使用任意静态文件服务器打开 `index.html` 即可，例如：

```bash
# Python
python3 -m http.server 8080
# Node
npx serve .
```

然后在浏览器打开 `http://localhost:8080/ai/xq/`。

> 说明：跨域通过浏览器直连 OpenAI API 需要在可访问的网络环境下运行（中国大陆网络通常不可直连 `api.openai.com`，可自行配置代理转发或第三方 API 地址）。

## 使用说明

1. 打开页面后，可先点击「接口设置」：
   - 点击 **DeepSeek** 快速填充：`https://api.deepseek.com/chat/completions` + `deepseek-v4-flash`，并默认勾选「关闭思考模式」。
   - 或点击 **OpenAI** 快速填充：`https://api.openai.com/v1/chat/completions` + `gpt-4-turbo`，默认开启 `response_format=json`。
   - 填入你的 API Key（仅保存在本地 localStorage）。
2. 选择「执红（先手）」或「执黑（后手）」开始对局。
3. 点击己方棋子选中，再点击目标位置走棋；合法走位会以圆点提示。
4. AI 走棋时会有“思考中”状态，走完后以气泡输出嘲讽。

若未填写有效的 API Key，或 AI 网络请求失败，系统会自动切换为内置引擎兜底，仍可正常对弈。

### DeepSeek 思考模式

DeepSeek 兼容 OpenAI 接口，但默认会开启思考（reasoning）。本平台在请求体中附带 `thinking: {"type": "disabled"}`（对应官方 SDK 的 `extra_body={"thinking": {"type": "disabled"}}`）以关闭思考、降低延迟与成本，并让输出更稳定地收敛为纯 JSON 下棋指令。可在设置中勾选/取消。

> 注意：`response_format` 目前 DeepSeek 不支持，本平台已对 DeepSeek 自动跳过该参数，仅靠系统提示词强制 JSON 输出并以前端规则引擎兜底校验。

### AI 下棋指令协议（AI 如何发送 / 系统如何接收）

AI 每走一步，其**整个回复就是一条“下棋指令”**，必须是一个纯 JSON 对象，例如：

```json
{"move": "炮二平五", "comment": "就这？我闭着眼都能赢你。", "evaluation": "红方先手略优", "strategy": "炮镇中路，控制局面"}
```

- **AI 如何发送**：只输出该 JSON，禁止额外文字、代码块或解释；`move` 为标准记谱法。
- **系统如何接收**：[ai.js](js/ai.js) 的 `extractJSON` 提取最外层 `{}` → 读取 `move` → [notation.js](js/notation.js) 解析成坐标 → [rules.js](js/rules.js) 的 `legalMoves` 校验合法性。
- **非法重试**：若 `move` 缺失/非法，不采纳并追加提醒，最多重试 3 次；仍失败则切换本地兜底引擎。

## 目录结构

```
ai/xq/
├── index.html          # 主页面
├── css/
│   ├── style.css       # 主样式
│   ├── board.css       # 棋盘样式
│   └── responsive.css  # 响应式样式
├── js/
│   ├── rules.js        # 象棋规则验证（走法、将军、终局）
│   ├── notation.js     # 记谱法转换
│   ├── prompt.js       # 提示词模板（系统/用户/终局）
│   ├── ai.js           # OpenAI API 调用 + 重试 + 兜底
│   ├── board.js        # Canvas 棋盘渲染
│   ├── ui.js           # 界面交互
│   └── main.js         # 主逻辑与状态管理
└── old/                # 历史版本备份
```

## 坐标约定

- 内部 `board[row][col]`，10 行 × 9 列。
- `board[0][0]` = 红方底线最左边（row 0 为红方，位于棋盘下方）。
- `board[9][8]` = 黑方底线最右边（row 9 为黑方，位于棋盘上方）。
- 红 = 大写（K帅 A仕 B相 N马 R车 C炮 P兵）；黑 = 小写（k将 a士 b象 n马 r车 c炮 p卒）。

## 安全提示

纯前端调用会直接在浏览器中发送你的 OpenAI API Key，存在被获取的风险。**建议仅使用个人测试 Key**，切勿在生产环境直接暴露。